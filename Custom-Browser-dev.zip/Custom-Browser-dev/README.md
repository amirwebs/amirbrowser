Custom browser

Custom browser is a fork of the Lightning-Browser for Android, modified to work with Appsgeyser template system.

Please notice that this app is unofficial and it's not affiliated with the Lightning-Browser project.

Browser template

browser template using this code could be found at http://www.appsgeyser.com/create-browser/